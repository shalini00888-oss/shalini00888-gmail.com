# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI web application based on the supplied project documentation.

## What it does

1. Collects story prompt, character name, setting, tone, and art style.
2. Uses Gemini to create a structured five-panel outline.
3. Uses a second Gemini call to create narration, captions, and dialogue.
4. Uses Hugging Face text-to-image inference with a Stable Diffusion model to create each panel.
5. Builds a layout object for the web preview.
6. Exports the five panels and story text into a multi-page PDF.
7. Exposes browser routes plus a JSON API.

The supplied documentation described Gemini 1.5 Flash/Pro and the older `google-generativeai` package. This implementation uses the current `google-genai` SDK and configurable Gemini model IDs so the application does not depend on the deprecated legacy SDK.

## Project structure

```text
ComicCraft/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── schemas.py
│   ├── routes.py
│   └── services/
│       ├── __init__.py
│       ├── gemini_flash.py
│       ├── gemini_pro.py
│       ├── image_generator.py
│       ├── layout_builder.py
│       └── exporters.py
├── templates/
│   ├── index.html
│   ├── comic_preview.html
│   └── export_success.html
├── static/
│   ├── css/styles.css
│   ├── panels/.gitkeep
│   └── exports/.gitkeep
├── tests/
│   ├── test_health.py
│   └── test_layout.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## VS Code setup — Windows

### 1. Install prerequisites

Install Python 3.11 or newer and VS Code.

### 2. Open the project

Extract the project ZIP and open the `ComicCraft` folder in VS Code.

### 3. Create a virtual environment

Open VS Code Terminal:

```powershell
py -m venv .venv
```

Activate it:

```powershell
.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:

```cmd
.venv\Scripts\activate
```

### 4. Install packages

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 5. Configure API keys

Copy:

```text
.env.example
```

to:

```text
.env
```

Then set:

```env
GEMINI_API_KEY=your_google_ai_studio_key
HF_API_KEY=your_hugging_face_token
```

Do not commit `.env` to Git.

### 6. Run the server

From the project root:

```powershell
uvicorn app.main:app --reload
```

Open:

- Home: http://127.0.0.1:8000
- Health: http://127.0.0.1:8000/health
- Swagger API docs: http://127.0.0.1:8000/docs

## How to test

### Test 1 — health check

Open:

```text
http://127.0.0.1:8000/health
```

Expected:

```json
{"status":"ok","service":"ComicCraft"}
```

### Test 2 — unit tests

```powershell
pytest -q
```

The tests do not call Gemini or Hugging Face.

### Test 3 — image endpoint

After adding `HF_API_KEY`, open:

```text
http://127.0.0.1:8000/test-image?prompt=A%20cute%20fox%20in%20an%20enchanted%20forest
```

A successful response contains an image URL.

### Test 4 — complete web flow

1. Open the home page.
2. Enter a story prompt.
3. Enter a character name.
4. Select setting, tone, and art style.
5. Click **Generate 5-Panel Comic**.
6. Wait while the two Gemini calls and five image calls complete.
7. Review the panels.
8. Click **Download Your Comic as PDF**.

## JSON API example

Use `/docs` → `POST /generate-comic/json`.

Example body:

```json
{
  "story_prompt": "A brave fox discovers a glowing door in an enchanted forest.",
  "character_name": "Luna",
  "setting": "Enchanted forest",
  "tone": "Adventurous",
  "art_style": "Comic book"
}
```

A successful response contains:

```json
{
  "success": true,
  "character_name": "Luna",
  "panels": [],
  "pdf_url": "/download/example.pdf"
}
```

## Image generation note

The default implementation uses Hugging Face hosted inference through `InferenceClient`, which keeps the normal installation manageable. Hugging Face documents `text_to_image()` and supports choosing a model and inference provider.

If you specifically need local Diffusers execution, install a compatible PyTorch build first, then:

```powershell
pip install -r requirements-local-diffusion.txt
```

A local Diffusers implementation can then replace the hosted image service without changing the rest of the application architecture.

## Common errors

### `GEMINI_API_KEY is missing`

Create `.env` in the project root and set the key.

### `HF_API_KEY is missing`

Create `.env` and set your Hugging Face token.

### Model/provider unavailable

Change `HF_IMAGE_MODEL` or `HF_PROVIDER` in `.env` to a text-to-image model/provider available to your Hugging Face account.

### PDF has replacement characters

The built-in FPDF core fonts are Latin-1 based. For multilingual PDF output, add a Unicode TTF font such as Noto Sans and register it with FPDF before writing text.

### Generation is slow

Five image generations are intentionally performed because the source project specifies one illustration per panel. Hosted inference speed depends on the selected provider and model.

## Architecture mapping to the supplied documentation

- `gemini_flash.py` → structured five-panel outline.
- `gemini_pro.py` → full narration/dialogue.
- `image_generator.py` → Stable Diffusion-compatible text-to-image generation.
- `layout_builder.py` → panel/image/story binding.
- `exporters.py` → multi-page PDF.
- `routes.py` → `/`, `/generate`, `/generate-comic/json`, `/export-success`, `/test-image`, and PDF download.
- Jinja2 templates → input, preview, and export-success pages.

## Security basics

- API keys are read from environment variables.
- `.env` is ignored by Git.
- Download filenames are constrained to the export directory.
- User fields are validated with Pydantic.
- Generated HTML uses Jinja2 escaping by default.
- The app does not store user accounts or a database, matching the supplied documentation's single-generation scope.

## Production improvements

For production deployment, add authentication, persistent storage, background jobs/queues for long image generation, rate limiting, database-backed comic history, object storage for images/PDFs, structured logging, and stronger content/safety controls.
