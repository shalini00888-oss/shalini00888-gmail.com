from functools import lru_cache
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    app_name: str = "ComicCraft"
    gemini_api_key: str = ""
    hf_api_key: str = ""

    # Current, stable Gemini models. Override in .env if your account uses others.
    gemini_flash_model: str = "gemini-2.5-flash"
    gemini_pro_model: str = "gemini-2.5-pro"

    # Hugging Face text-to-image model. Override if your account/provider uses another.
    hf_image_model: str = "stable-diffusion-v1-5/stable-diffusion-v1-5"
    hf_provider: str = "auto"

    image_width: int = 768
    image_height: int = 512
    image_steps: int = 25
    image_guidance: float = 7.0
    request_timeout: float = 180.0

    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"),
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )


@lru_cache
def get_settings() -> Settings:
    return Settings()
