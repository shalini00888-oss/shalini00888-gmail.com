from pydantic import BaseModel, Field, field_validator


class PanelOutline(BaseModel):
    panel_number: int = Field(ge=1, le=5)
    title: str = Field(min_length=1, max_length=100)
    scene_description: str = Field(min_length=1, max_length=1000)
    image_prompt: str = Field(min_length=1, max_length=1500)


class ComicOutline(BaseModel):
    panels: list[PanelOutline] = Field(min_length=5, max_length=5)


class ComicRequest(BaseModel):
    story_prompt: str = Field(min_length=5, max_length=2000)
    character_name: str = Field(min_length=1, max_length=80)
    setting: str = Field(min_length=1, max_length=120)
    tone: str = Field(min_length=1, max_length=80)
    art_style: str = Field(min_length=1, max_length=120)

    @field_validator("story_prompt", "character_name", "setting", "tone", "art_style")
    @classmethod
    def strip_values(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Value cannot be empty.")
        return value


class PanelStory(BaseModel):
    panel_number: int = Field(ge=1, le=5)
    title: str
    scene_description: str
    caption: str
    narration: str
    dialogue: list[str] = Field(default_factory=list)


class ComicStory(BaseModel):
    panels: list[PanelStory] = Field(min_length=5, max_length=5)
