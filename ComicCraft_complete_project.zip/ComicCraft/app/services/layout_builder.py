from app.schemas import ComicOutline, ComicStory


def build_comic_layout(outline: ComicOutline, story: ComicStory, images: list[str]) -> list[dict]:
    story_by_number = {panel.panel_number: panel for panel in story.panels}
    outline_by_number = {panel.panel_number: panel for panel in outline.panels}

    layout = []
    for index, image_path in enumerate(images, start=1):
        outline_panel = outline_by_number[index]
        story_panel = story_by_number[index]
        layout.append(
            {
                "panel_number": index,
                "title": story_panel.title or outline_panel.title,
                "image_path": image_path,
                "image_url": f"/static/panels/{image_path.split('/')[-1]}",
                "scene_description": story_panel.scene_description or outline_panel.scene_description,
                "caption": story_panel.caption,
                "narration": story_panel.narration,
                "dialogue": story_panel.dialogue,
                "image_prompt": outline_panel.image_prompt,
            }
        )
    return layout
