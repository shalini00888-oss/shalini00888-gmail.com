import json

from google import genai
from google.genai import types

from app.config import get_settings
from app.schemas import ComicOutline, ComicRequest


def _client() -> genai.Client:
    settings = get_settings()
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is missing. Add it to your .env file.")
    return genai.Client(api_key=settings.gemini_api_key)


def generate_outline(data: ComicRequest) -> ComicOutline:
    settings = get_settings()
    prompt = f"""
Create exactly five connected comic panels.

User story idea: {data.story_prompt}
Main character: {data.character_name}
Setting: {data.setting}
Tone: {data.tone}
Art style: {data.art_style}

Requirements:
- Make the five panels form one coherent beginning, middle, and ending.
- Keep the main character visually consistent across panels.
- For every panel provide a short title, a vivid scene description, and a detailed
  image-generation prompt.
- Do not put dialogue in the image prompt; the application adds text separately.
- Avoid unsafe, hateful, sexual, or graphic content.
- Return only the requested JSON structure.
"""
    response = _client().models.generate_content(
        model=settings.gemini_flash_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=ComicOutline,
            temperature=0.8,
        ),
    )

    if not response.text:
        raise RuntimeError("Gemini returned an empty outline.")
    try:
        data_obj = json.loads(response.text)
        return ComicOutline.model_validate(data_obj)
    except Exception as exc:
        raise RuntimeError(f"Could not parse Gemini outline JSON: {exc}") from exc
