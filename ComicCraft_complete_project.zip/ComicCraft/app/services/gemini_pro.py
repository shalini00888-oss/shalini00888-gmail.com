import json

from google import genai
from google.genai import types

from app.config import get_settings
from app.schemas import ComicOutline, ComicRequest, ComicStory


def _client() -> genai.Client:
    settings = get_settings()
    if not settings.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is missing. Add it to your .env file.")
    return genai.Client(api_key=settings.gemini_api_key)


def generate_story(data: ComicRequest, outline: ComicOutline) -> ComicStory:
    settings = get_settings()
    outline_json = outline.model_dump_json(indent=2)

    prompt = f"""
Expand this five-panel outline into a polished comic script.

Character: {data.character_name}
Setting: {data.setting}
Tone: {data.tone}
Art style: {data.art_style}
Original story prompt: {data.story_prompt}

Outline:
{outline_json}

For each of the five panels provide:
- panel_number
- title
- scene_description
- caption: a short comic caption or ambient line
- narration: concise narration describing action/emotion
- dialogue: zero or more short dialogue lines

Keep character names and events consistent with the outline. Do not introduce
major new characters or locations unless needed for continuity. Keep the language
family-friendly and avoid graphic violence, sexual content, hate, or instructions
for dangerous activities. Return only the requested JSON structure.
"""
    response = _client().models.generate_content(
        model=settings.gemini_pro_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=ComicStory,
            temperature=0.9,
        ),
    )

    if not response.text:
        raise RuntimeError("Gemini returned an empty story.")
    try:
        return ComicStory.model_validate(json.loads(response.text))
    except Exception as exc:
        raise RuntimeError(f"Could not parse Gemini story JSON: {exc}") from exc
