from pathlib import Path
from datetime import datetime
import re

from fpdf import FPDF

BASE_DIR = Path(__file__).resolve().parents[2]
EXPORT_DIR = BASE_DIR / "static" / "exports"
EXPORT_DIR.mkdir(parents=True, exist_ok=True)


def _clean_filename(value: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9_-]+", "-", value).strip("-")
    return value[:50] or "comic"


def _latin_safe(text: str) -> str:
    # Core FPDF fonts are Latin-1. Replace unsupported Unicode gracefully.
    return text.encode("latin-1", "replace").decode("latin-1")


def save_pdf(layout: list[dict], title: str = "ComicCraft Comic") -> str:
    filename = (
        f"{_clean_filename(title)}-"
        f"{datetime.now().strftime('%Y%m%d-%H%M%S')}.pdf"
    )
    output = EXPORT_DIR / filename

    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout:
        pdf.add_page()
        pdf.set_title(title)
        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(0, 10, _latin_safe(f"Panel {panel['panel_number']}: {panel['title']}"))

        image_file = Path(panel["image_path"])
        if image_file.exists():
            pdf.image(str(image_file), x=15, y=35, w=180)
            pdf.ln(115)

        pdf.set_font("Helvetica", "I", 11)
        pdf.multi_cell(0, 7, _latin_safe(panel["scene_description"]))
        pdf.ln(2)

        if panel["caption"]:
            pdf.set_font("Helvetica", "B", 11)
            pdf.multi_cell(0, 7, _latin_safe(f"Caption: {panel['caption']}"))

        pdf.set_font("Helvetica", "", 11)
        if panel["narration"]:
            pdf.multi_cell(0, 7, _latin_safe(f"Narration: {panel['narration']}"))

        for line in panel.get("dialogue", []):
            pdf.multi_cell(0, 7, _latin_safe(f"Dialogue: {line}"))

    pdf.output(str(output))
    return str(output)
