from pathlib import Path
import re
from PIL import Image

from huggingface_hub import InferenceClient

from app.config import get_settings

BASE_DIR = Path(__file__).resolve().parents[2]
PANEL_DIR = BASE_DIR / "static" / "panels"
PANEL_DIR.mkdir(parents=True, exist_ok=True)


def _safe_filename(text: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9_-]+", "-", text.lower()).strip("-")
    return value[:60] or "panel"


def generate_image(prompt: str, art_style: str = "comic book", panel_number: int = 1) -> str:
    settings = get_settings()
    if not settings.hf_api_key:
        raise RuntimeError("HF_API_KEY is missing. Add it to your .env file.")

    final_prompt = (
        f"{prompt}. Visual style: {art_style}. "
        "single comic panel, strong composition, expressive characters, "
        "clean line art, vivid colors, consistent character design, "
        "no speech bubbles, no captions, no watermark, no text."
    )
    client = InferenceClient(
        provider=settings.hf_provider,
        api_key=settings.hf_api_key,
        timeout=settings.request_timeout,
    )

    image: Image.Image = client.text_to_image(
        prompt=final_prompt,
        negative_prompt="blurry, low quality, distorted anatomy, extra limbs, text, watermark, logo",
        width=settings.image_width,
        height=settings.image_height,
        num_inference_steps=settings.image_steps,
        guidance_scale=settings.image_guidance,
        model=settings.hf_image_model,
    )

    filename = f"panel-{panel_number:02d}-{_safe_filename(prompt)}.png"
    output = PANEL_DIR / filename
    image.save(output, format="PNG")
    return str(output)
