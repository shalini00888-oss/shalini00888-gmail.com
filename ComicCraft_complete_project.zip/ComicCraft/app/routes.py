from pathlib import Path
from uuid import uuid4

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.templating import Jinja2Templates

from app.config import get_settings
from app.schemas import ComicRequest
from app.services.gemini_flash import generate_outline
from app.services.gemini_pro import generate_story
from app.services.image_generator import generate_image
from app.services.layout_builder import build_comic_layout
from app.services.exporters import save_pdf

router = APIRouter()
BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


@router.get("/")
async def home(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"error": None},
    )


async def create_comic(data: ComicRequest):
    outline = generate_outline(data)
    story = generate_story(data, outline)

    images = []
    for panel in outline.panels:
        image_path = generate_image(
            panel.image_prompt,
            art_style=data.art_style,
            panel_number=panel.panel_number,
        )
        images.append(image_path)

    layout = build_comic_layout(outline, story, images)
    pdf_path = save_pdf(layout, title=f"ComicCraft - {data.character_name}")
    return layout, pdf_path


@router.post("/generate")
async def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        data = ComicRequest(
            story_prompt=story_prompt,
            character_name=character_name,
            setting=setting,
            tone=tone,
            art_style=art_style,
        )
        layout, pdf_path = await create_comic(data)
        return templates.TemplateResponse(
            request=request,
            name="comic_preview.html",
            context={
                "layout": layout,
                "pdf_url": f"/download/{Path(pdf_path).name}",
                "character_name": data.character_name,
                "error": None,
            },
        )
    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={"error": str(exc)},
            status_code=500,
        )


@router.post("/generate-comic/json")
async def generate_json(payload: ComicRequest):
    try:
        layout, pdf_path = await create_comic(payload)
        return JSONResponse(
            {
                "success": True,
                "character_name": payload.character_name,
                "panels": layout,
                "pdf_url": f"/download/{Path(pdf_path).name}",
            }
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get("/download/{filename}", name="download_pdf")
async def download_pdf(filename: str):
    settings = get_settings()
    export_dir = BASE_DIR / "static" / "exports"
    candidate = (export_dir / filename).resolve()

    if candidate.parent != export_dir.resolve() or candidate.suffix.lower() != ".pdf":
        raise HTTPException(status_code=400, detail="Invalid export filename.")
    if not candidate.exists():
        raise HTTPException(status_code=404, detail="PDF not found.")

    return FileResponse(
        candidate,
        media_type="application/pdf",
        filename=candidate.name,
        headers={"Cache-Control": "no-store"},
    )


@router.get("/export-success")
async def export_success(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="export_success.html",
        context={},
    )


@router.get("/test-image")
async def test_image(prompt: str = "A cute fox in an enchanted forest, comic book illustration"):
    try:
        image_path = generate_image(prompt, art_style="comic book", panel_number=1)
        return {"success": True, "image_url": f"/static/panels/{Path(image_path).name}"}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
