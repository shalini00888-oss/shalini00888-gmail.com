from app.schemas import ComicOutline, ComicRequest, ComicStory, PanelOutline, PanelStory
from app.services.layout_builder import build_comic_layout


def test_layout_pairs_outline_story_and_images():
    outline = ComicOutline(
        panels=[
            PanelOutline(
                panel_number=i,
                title=f"Panel {i}",
                scene_description=f"Scene {i}",
                image_prompt=f"Image {i}",
            )
            for i in range(1, 6)
        ]
    )
    story = ComicStory(
        panels=[
            PanelStory(
                panel_number=i,
                title=f"Story {i}",
                scene_description=f"Story scene {i}",
                caption=f"Caption {i}",
                narration=f"Narration {i}",
                dialogue=[f"Hello {i}"],
            )
            for i in range(1, 6)
        ]
    )
    images = [f"/tmp/panel-{i}.png" for i in range(1, 6)]

    result = build_comic_layout(outline, story, images)

    assert len(result) == 5
    assert result[0]["panel_number"] == 1
    assert result[4]["panel_number"] == 5
    assert result[2]["title"] == "Story 3"
